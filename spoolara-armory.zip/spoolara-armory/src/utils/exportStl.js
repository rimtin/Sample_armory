import * as THREE from "three";
import { STLExporter } from "three/examples/jsm/exporters/STLExporter.js";

/**
 * exportStl.js — write print-ready STLs.
 *
 * For printing, only a part's real-world SIZE matters, not where it sits on the
 * avatar. We bake the fitted scale (+ manual rotation/scale) into the geometry,
 * convert metres → millimetres (every slicer's unit), re-centre at the origin,
 * and download a binary STL.
 */
const M_TO_MM = 1000;

function bakeGeometry(geometry, totalScale, quaternion) {
  const g = geometry.clone();
  const m = new THREE.Matrix4();
  const r = new THREE.Matrix4().makeRotationFromQuaternion(
    quaternion || new THREE.Quaternion()
  );
  const s = new THREE.Matrix4().makeScale(
    totalScale * M_TO_MM,
    totalScale * M_TO_MM,
    totalScale * M_TO_MM
  );
  m.multiplyMatrices(s, r);
  g.applyMatrix4(m);
  g.computeBoundingBox();
  const c = new THREE.Vector3();
  g.boundingBox.getCenter(c);
  g.translate(-c.x, -c.y, -c.z);
  return g;
}

function download(data, filename) {
  const blob = new Blob([data], { type: "application/octet-stream" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/** Export a single fitted part. */
export function exportPart(part) {
  const g = bakeGeometry(part.geometry, part.totalScale, part.quaternion);
  const mesh = new THREE.Mesh(g, new THREE.MeshStandardMaterial());
  const data = new STLExporter().parse(mesh, { binary: true });
  const base = part.filename.replace(/\.stl$/i, "");
  download(data, `${base}_fitted.stl`);
}

/**
 * Export every part as one combined assembly, preserving each part's relative
 * position/orientation on the body (so the assembly prints as posed). Units mm.
 */
export function exportAssembly(parts) {
  const group = new THREE.Group();
  for (const p of parts) {
    const g = p.geometry.clone();
    const m = new THREE.Matrix4().compose(
      new THREE.Vector3(
        p.position[0] * M_TO_MM,
        p.position[1] * M_TO_MM,
        p.position[2] * M_TO_MM
      ),
      new THREE.Quaternion(...p.quaternion),
      new THREE.Vector3(
        p.totalScale * M_TO_MM,
        p.totalScale * M_TO_MM,
        p.totalScale * M_TO_MM
      )
    );
    g.applyMatrix4(m);
    group.add(new THREE.Mesh(g));
  }
  group.updateMatrixWorld(true);
  const data = new STLExporter().parse(group, { binary: true });
  download(data, `armor-assembly-${parts.length}-parts.stl`);
}
