/**
 * bodyModel.js — the anatomical knowledge the fitter needs.
 *
 * The avatar GLB is rigged with real bones (verified positions):
 *   Head, Neck, Spine, Hips,
 *   Shoulder/UpperArm/ForeArm/Hand .L/.R,
 *   UpperLeg/LowerLeg/Foot .L/.R
 *
 * A part fits a person when we know three things:
 *   1. ANCHOR  — which bone(s) it sits on (we use their live world position)
 *   2. AXIS    — which way the body segment runs (derived from bone→bone
 *                vectors at fit time, so it survives any pose/scale change)
 *   3. SIZE    — the real-world target size, from the user's measurement plus a
 *                Tight/Snug/Loose allowance.
 *
 * SIZE METHOD is hybrid (per the brief's spirit):
 *   - girth  : wrap-around armor (helmet, torso, limbs) sizes by
 *              circumference → diameter (diameter = circ / π)
 *   - length : helmet height / boots size by a real-world length measurement
 */

// All measurements in centimetres.
export const MEASUREMENTS = [
  { key: "height", label: "Height", min: 120, max: 220, default: 178 },
  { key: "headCircumference", label: "Head circumference", min: 45, max: 65, default: 57, circ: true },
  { key: "neckCircumference", label: "Neck circumference", min: 28, max: 50, default: 38, circ: true },
  { key: "shoulderWidth", label: "Shoulder width", min: 30, max: 60, default: 46 },
  { key: "chestCircumference", label: "Chest circumference", min: 70, max: 140, default: 100, circ: true },
  { key: "waistCircumference", label: "Waist circumference", min: 60, max: 140, default: 85, circ: true },
  { key: "hipCircumference", label: "Hip circumference", min: 70, max: 150, default: 98, circ: true },
  { key: "upperArmCircumference", label: "Upper-arm circumference", min: 20, max: 50, default: 32, circ: true },
  { key: "forearmCircumference", label: "Forearm circumference", min: 18, max: 40, default: 27, circ: true },
  { key: "thighCircumference", label: "Thigh circumference", min: 35, max: 80, default: 56, circ: true },
  { key: "calfCircumference", label: "Calf circumference", min: 25, max: 55, default: 38, circ: true },
  { key: "footLength", label: "Foot length", min: 20, max: 35, default: 27 },
];

export const DEFAULT_MEASUREMENTS = Object.fromEntries(
  MEASUREMENTS.map((m) => [m.key, m.default])
);

// Clearance over the body measurement. A shell must be ≥ body size + air gap.
export const FIT_PRESETS = {
  Tight: 1.02,
  Snug: 1.06,
  Loose: 1.12,
};

const circToDiameter = (c) => c / Math.PI;

/**
 * Region table. `anchor` lists bone names whose world positions are averaged to
 * place the part. `along` (optional) is a [from,to] bone pair whose vector tells
 * us how the segment is oriented, so a limb piece aligns to the limb. `size`
 * returns the target real-world size (cm) for the part's dominant fit axis.
 * `method` chooses girth vs length sizing.
 */
export const REGIONS = {
  helmet: {
    label: "Helmet / Head",
    anchor: ["Head"],
    method: "girth",
    size: (m) => circToDiameter(m.headCircumference),
    keywords: ["helmet", "hood", "dome", "faceplate", "mask", "head", "chin", "ear", "antenna", "cam", "led"],
  },
  neck: {
    label: "Neck / Collar",
    anchor: ["Neck"],
    method: "girth",
    size: (m) => circToDiameter(m.neckCircumference),
    keywords: ["neck", "collar", "gorget"],
  },
  chest: {
    label: "Chest / Torso",
    anchor: ["Spine"],
    method: "girth",
    size: (m) => circToDiameter(m.chestCircumference),
    keywords: ["chest", "torso", "cuirass", "breast", "pad"],
  },
  back: {
    label: "Back / Jetpack",
    anchor: ["Spine"],
    method: "girth",
    size: (m) => circToDiameter(m.chestCircumference) * 0.9,
    keywords: ["back", "jetpack", "jet", "plug"],
  },
  waist: {
    label: "Waist / Belt",
    anchor: ["Hips"],
    method: "girth",
    size: (m) => circToDiameter(m.waistCircumference),
    keywords: ["belt", "waist", "box", "holster", "ass", "peepee"],
  },
  shoulderL: {
    label: "Shoulder (L)",
    anchor: ["Shoulder.L", "UpperArm.L"],
    along: ["Shoulder.L", "UpperArm.L"],
    method: "girth",
    size: (m) => circToDiameter(m.upperArmCircumference) * 1.4,
    keywords: ["shoulder_l", "shoulder.l", "shoulder l", "pauldron_l"],
  },
  shoulderR: {
    label: "Shoulder (R)",
    anchor: ["Shoulder.R", "UpperArm.R"],
    along: ["Shoulder.R", "UpperArm.R"],
    method: "girth",
    size: (m) => circToDiameter(m.upperArmCircumference) * 1.4,
    keywords: ["shoulder_r", "shoulder.r", "shoulder r", "pauldron_r"],
  },
  upperArmL: {
    label: "Upper arm (L)",
    anchor: ["UpperArm.L", "ForeArm.L"],
    along: ["UpperArm.L", "ForeArm.L"],
    method: "girth",
    size: (m) => circToDiameter(m.upperArmCircumference),
    keywords: ["upperarm", "bicep", "arm1"],
  },
  upperArmR: {
    label: "Upper arm (R)",
    anchor: ["UpperArm.R", "ForeArm.R"],
    along: ["UpperArm.R", "ForeArm.R"],
    method: "girth",
    size: (m) => circToDiameter(m.upperArmCircumference),
    keywords: [],
  },
  forearmL: {
    label: "Forearm (L)",
    anchor: ["ForeArm.L", "Hand.L"],
    along: ["ForeArm.L", "Hand.L"],
    method: "girth",
    size: (m) => circToDiameter(m.forearmCircumference),
    keywords: ["forearm", "bracer", "gauntlet", "communicator"],
  },
  forearmR: {
    label: "Forearm (R)",
    anchor: ["ForeArm.R", "Hand.R"],
    along: ["ForeArm.R", "Hand.R"],
    method: "girth",
    size: (m) => circToDiameter(m.forearmCircumference),
    keywords: [],
  },
  thighL: {
    label: "Thigh (L)",
    anchor: ["UpperLeg.L", "LowerLeg.L"],
    along: ["UpperLeg.L", "LowerLeg.L"],
    method: "girth",
    size: (m) => circToDiameter(m.thighCircumference),
    keywords: ["thigh", "upperleg"],
  },
  thighR: {
    label: "Thigh (R)",
    anchor: ["UpperLeg.R", "LowerLeg.R"],
    along: ["UpperLeg.R", "LowerLeg.R"],
    method: "girth",
    size: (m) => circToDiameter(m.thighCircumference),
    keywords: [],
  },
  calfL: {
    label: "Calf / Shin (L)",
    anchor: ["LowerLeg.L", "Foot.L"],
    along: ["LowerLeg.L", "Foot.L"],
    method: "girth",
    size: (m) => circToDiameter(m.calfCircumference),
    keywords: ["calf", "shin", "lowerleg"],
  },
  calfR: {
    label: "Calf / Shin (R)",
    anchor: ["LowerLeg.R", "Foot.R"],
    along: ["LowerLeg.R", "Foot.R"],
    method: "girth",
    size: (m) => circToDiameter(m.calfCircumference),
    keywords: [],
  },
  footL: {
    label: "Foot / Boot (L)",
    anchor: ["Foot.L"],
    method: "length",
    size: (m) => m.footLength,
    keywords: ["foot", "boot", "shoe", "left/1", "left/2"],
  },
  footR: {
    label: "Foot / Boot (R)",
    anchor: ["Foot.R"],
    method: "length",
    size: (m) => m.footLength,
    keywords: ["right/1", "right/2"],
  },
};

export const REGION_OPTIONS = Object.entries(REGIONS).map(([id, r]) => ({
  id,
  label: r.label,
}));

/**
 * Auto-detect a region from the file's name AND its folder path (the sample
 * set encodes the body part in folders like ARMS/LEFT, LEGS/RIGHT, HELMET_P1).
 * Side (L/R) from the path overrides a side-less keyword match.
 */
export function detectRegion(pathOrName) {
  const p = pathOrName.toLowerCase().replace(/\\/g, "/");
  const isLeft = /\/left\/|_l\b|left/.test(p);
  const isRight = /\/right\/|_r\b|right/.test(p);

  // strongest signal: folder-based body part
  if (/\/arms?\//.test(p)) {
    if (/shoulder/.test(p)) return isRight ? "shoulderR" : "shoulderL";
    if (/arm1|upper|bicep/.test(p)) return isRight ? "upperArmR" : "upperArmL";
    return isRight ? "forearmR" : "forearmL";
  }
  if (/\/legs?\//.test(p)) {
    if (/[1-2]\.stl$/.test(p)) return isRight ? "footR" : "footL";
    if (/[4-5]\.stl$/.test(p)) return isRight ? "thighR" : "thighL";
    return isRight ? "calfR" : "calfL";
  }
  if (/\/torso\//.test(p)) return /back|jetpack/.test(p) ? "back" : "chest";
  if (/\/belt\//.test(p)) return "waist";
  if (/\/jetpack\//.test(p)) return "back";
  if (/helmet/.test(p)) return "helmet";

  // fall back to keyword scan
  for (const [id, r] of Object.entries(REGIONS)) {
    if (r.keywords.some((k) => p.includes(k))) {
      if (id.endsWith("L") && isRight) return id.slice(0, -1) + "R";
      return id;
    }
  }
  return "chest";
}
