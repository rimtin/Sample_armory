import * as THREE from "three";
import { REGIONS, FIT_PRESETS } from "./bodyModel.js";

/**
 * fitting.js — turn a raw STL into a part that fits a real body.
 *
 * The hard facts about STL input (confirmed from the sample set):
 *   - no units, no consistent scale
 *   - arbitrary origin (the sample helmet's box sits ~9650 units off-origin)
 * So we never trust the STL's raw size or position. We measure its bounding
 * box, then scale it to a target real-world size and anchor it to a bone.
 *
 * Scene convention: 1 unit = 1 metre.
 */

const CM_TO_UNITS = 0.01;

export function measure(geometry) {
  geometry.computeBoundingBox();
  const size = new THREE.Vector3();
  const center = new THREE.Vector3();
  geometry.boundingBox.getSize(size);
  geometry.boundingBox.getCenter(center);
  return { size, center };
}

/**
 * Pick the STL dimension to fit against:
 *   - girth method  → second-largest extent (the "around the body" axis; the
 *     largest is usually the part's length/height which we don't constrain)
 *   - length method → largest extent (helmet height, boot length)
 */
function fitDimension(size, method) {
  const v = [size.x, size.y, size.z].sort((a, b) => b - a);
  return method === "length" ? v[0] : v[1];
}

/**
 * anatomyAnchor — a point on the avatar derived from its rendered bounding box
 * and standard human proportions. Ratios are fraction-of-height up from the
 * feet (yR) and fraction-of-width from centre (xR, + = right/avatar-left in our
 * T-pose). frontZ pushes torso/face pieces to the body's front surface.
 *
 * This is robust: it always matches the visible avatar regardless of how the
 * skeleton's bind pose is authored.
 */
const ANATOMY = {
  helmet:    { yR: 0.95, xR: 0.0,  z: "center" },
  neck:      { yR: 0.87, xR: 0.0,  z: "center" },
  chest:     { yR: 0.74, xR: 0.0,  z: "front"  },
  back:      { yR: 0.74, xR: 0.0,  z: "back"   },
  waist:     { yR: 0.60, xR: 0.0,  z: "front"  },
  shoulderL: { yR: 0.82, xR: -0.18, z: "center" },
  shoulderR: { yR: 0.82, xR: 0.18,  z: "center" },
  upperArmL: { yR: 0.78, xR: -0.30, z: "center" },
  upperArmR: { yR: 0.78, xR: 0.30,  z: "center" },
  forearmL:  { yR: 0.78, xR: -0.42, z: "center" },
  forearmR:  { yR: 0.78, xR: 0.42,  z: "center" },
  thighL:    { yR: 0.40, xR: -0.09, z: "center" },
  thighR:    { yR: 0.40, xR: 0.09,  z: "center" },
  calfL:     { yR: 0.20, xR: -0.09, z: "center" },
  calfR:     { yR: 0.20, xR: 0.09,  z: "center" },
  footL:     { yR: 0.04, xR: -0.09, z: "front"  },
  footR:     { yR: 0.04, xR: 0.09,  z: "front"  },
};

function anatomyAnchor(region, box) {
  const a = ANATOMY[regionKey(region)] || ANATOMY.chest;
  if (!box) return new THREE.Vector3(0, 1, 0);
  const min = box.min, max = box.max;
  const h = max.y - min.y;
  const w = max.x - min.x;
  const cz = (min.z + max.z) / 2;
  const x = (min.x + max.x) / 2 + a.xR * w;
  const y = min.y + a.yR * h;
  let z = cz;
  if (a.z === "front") z = max.z;
  else if (a.z === "back") z = min.z;
  return new THREE.Vector3(x, y, z);
}

// REGIONS values don't carry their own key, so resolve it back for ANATOMY.
function regionKey(region) {
  for (const [k, v] of Object.entries(REGIONS)) if (v === region) return k;
  return "chest";
}

/**
 * Compute the full auto-fit for a part.
 *
 * @param geometry      origin-centred BufferGeometry
 * @param regionId      key in REGIONS
 * @param fitLevel      "Tight" | "Snug" | "Loose"
 * @param measurements  cm values
 * @param boneWorld     { boneName: THREE.Vector3 } live world positions
 * @returns { scale, position:[x,y,z], quaternion:[x,y,z,w], targetCm }
 */
export function computeFit({ geometry, regionId, fitLevel, measurements, boneWorld, avatarBox }) {
  const region = REGIONS[regionId] || REGIONS.chest;
  const { size } = measure(geometry);

  // --- target real-world size + clearance ---
  const baseCm = region.size(measurements);
  const allow = FIT_PRESETS[fitLevel] ?? FIT_PRESETS.Snug;
  const targetCm = baseCm * allow;

  // --- uniform scale: chosen STL dimension → target size ---
  const dim = fitDimension(size, region.method);
  const targetUnits = targetCm * CM_TO_UNITS;
  const scale = dim > 1e-6 ? targetUnits / dim : 1;

  // --- anchor position ---
  // Anchor from the avatar's TRUE (GPU-skinned) bounding box using anatomical
  // ratios. The skinned box matches what's actually drawn, so parts seat on the
  // visible body. Bone vectors are still used for limb ORIENTATION below.
  let position = anatomyAnchor(region, avatarBox);

  // optional fine bias (metres at 178cm), scaled with height
  if (region.anchorBias) {
    const hScale = (measurements.height || 178) / 178;
    position.x += region.anchorBias[0] * hScale;
    position.y += region.anchorBias[1] * hScale;
    position.z += region.anchorBias[2] * hScale;
  }

  // --- orientation: align part's local up (+Y) to the body segment axis ---
  let quaternion = new THREE.Quaternion();
  if (region.along && boneWorld[region.along[0]] && boneWorld[region.along[1]]) {
    const dir = new THREE.Vector3()
      .subVectors(boneWorld[region.along[1]], boneWorld[region.along[0]])
      .normalize();
    if (dir.lengthSq() > 1e-6) {
      quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
    }
  }

  return {
    scale,
    position: [position.x, position.y, position.z],
    quaternion: [quaternion.x, quaternion.y, quaternion.z, quaternion.w],
    targetCm,
  };
}

/**
 * Real-world dimensions (cm) of a part at a given total scale, for the live
 * readout so the user can confirm the fit matches their body.
 */
export function dimensionsCm(geometry, totalScale) {
  const { size } = measure(geometry);
  return {
    x: size.x * totalScale * 100,
    y: size.y * totalScale * 100,
    z: size.z * totalScale * 100,
  };
}
