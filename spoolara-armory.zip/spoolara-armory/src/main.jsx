import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import "./styles.css";

// NOTE: StrictMode intentionally omitted. It double-invokes effects in dev,
// which re-runs the avatar's imperative scaling/bone-capture against a
// transient state and desyncs part anchoring. The app is effect-correct; this
// keeps the imperative Three.js setup deterministic.
createRoot(document.getElementById("root")).render(<App />);
