import React from "react";
import { REGION_OPTIONS, FIT_PRESETS } from "../utils/bodyModel.js";

const STYLES = ["Metallic", "Matte", "Glossy", "Emissive"];

/**
 * PartEditor — all controls for the selected part: region, auto-fit level,
 * colour/style, live fitted-size readout, manual nudge/rotate/scale, gizmo
 * mode, flips, export, remove.
 */
export default function PartEditor({
  part,
  gizmoMode,
  onGizmo,
  onChange,
  onManual,
  onAutoFit,
  onFlip,
  onExport,
  onRemove,
}) {
  if (!part) return null;
  const man = part.manual;

  return (
    <section className="card">
      <div className="card-head">
        <h3 className="card-title">Selected part</h3>
        <span className="part-file" title={part.filename}>{part.filename}</span>
      </div>

      <div className="field">
        <label>Body region</label>
        <select value={part.regionId} onChange={(e) => onChange({ regionId: e.target.value })}>
          {REGION_OPTIONS.map((o) => (
            <option key={o.id} value={o.id}>{o.label}</option>
          ))}
        </select>
      </div>

      <div className="field">
        <label>Auto fit</label>
        <div className="seg">
          {Object.keys(FIT_PRESETS).map((f) => (
            <button
              key={f}
              className={"seg-btn" + (part.fitLevel === f ? " active" : "")}
              onClick={() => onAutoFit(f)}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="field-row">
        <div className="field">
          <label>Colour</label>
          <input type="color" value={part.color} onChange={(e) => onChange({ color: e.target.value })} />
        </div>
        <div className="field">
          <label>Style</label>
          <select value={part.style} onChange={(e) => onChange({ style: e.target.value })}>
            {STYLES.map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>
      </div>

      {part.dims && (
        <div className="dims">
          Fitted size&nbsp;
          <strong>{part.dims.x.toFixed(1)} × {part.dims.y.toFixed(1)} × {part.dims.z.toFixed(1)} cm</strong>
        </div>
      )}

      {/* manual editing */}
      <div className="field">
        <label>Manual arrange</label>
        <div className="seg">
          {["translate", "rotate", "scale"].map((mode) => (
            <button
              key={mode}
              className={"seg-btn" + (gizmoMode === mode ? " active" : "")}
              onClick={() => onGizmo(mode)}
            >
              {mode === "translate" ? "Move" : mode[0].toUpperCase() + mode.slice(1)}
            </button>
          ))}
        </div>
        <p className="hint">Drag the on-body handles, or use G / R / S keys.</p>
      </div>

      <label className="slider-label">
        Size {Math.round((man.scaleMul ?? 1) * 100)}%
        <input
          type="range" min="0.5" max="1.8" step="0.01"
          value={man.scaleMul ?? 1}
          onChange={(e) => onManual({ scaleMul: Number(e.target.value) })}
        />
      </label>

      <div className="triplet">
        <span className="triplet-title">Nudge (cm)</span>
        {["x", "y", "z"].map((a) => (
          <label key={a}>{a.toUpperCase()}
            <input type="number" step="0.5"
              value={((man.offset?.[a] ?? 0) * 100).toFixed(1)}
              onChange={(e) => onManual({ offset: { ...man.offset, [a]: Number(e.target.value) / 100 } })}
            />
          </label>
        ))}
      </div>

      <div className="triplet">
        <span className="triplet-title">Rotate (°)</span>
        {["x", "y", "z"].map((a) => (
          <label key={a}>{a.toUpperCase()}
            <input type="number" step="5"
              value={man.rotation?.[a] ?? 0}
              onChange={(e) => onManual({ rotation: { ...man.rotation, [a]: Number(e.target.value) } })}
            />
          </label>
        ))}
      </div>

      <div className="flip-row">
        <button className="btn btn-ghost sm" onClick={() => onFlip("x")}>Flip X</button>
        <button className="btn btn-ghost sm" onClick={() => onFlip("y")}>Flip Y</button>
        <button className="btn btn-ghost sm" onClick={() => onFlip("z")}>Rot Z 90°</button>
      </div>

      <div className="part-actions">
        <button className="btn btn-accent" onClick={onExport}>Export this part (mm)</button>
        <button className="btn btn-ghost" onClick={onRemove}>Remove part</button>
      </div>
    </section>
  );
}
