import React from "react";
import { MEASUREMENTS } from "../utils/bodyModel.js";

export default function MeasurementsPanel({ values, onChange }) {
  return (
    <section className="card">
      <h3 className="card-title">Body measurements</h3>
      <p className="card-sub">
        Enter real measurements in centimetres. The avatar rescales by height and
        every fitted part re-anchors live.
      </p>
      <div className="measure-list">
        {MEASUREMENTS.map((m) => (
          <div className="measure-row" key={m.key}>
            <label htmlFor={m.key}>
              {m.label}
              {m.circ ? " (around)" : ""}
            </label>
            <div className="measure-controls">
              <input
                type="range"
                min={m.min}
                max={m.max}
                value={values[m.key]}
                onChange={(e) => onChange(m.key, Number(e.target.value))}
              />
              <input
                id={m.key}
                type="number"
                min={m.min}
                max={m.max}
                value={values[m.key]}
                onChange={(e) => onChange(m.key, Number(e.target.value))}
                className="measure-num"
              />
              <span className="unit">cm</span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
