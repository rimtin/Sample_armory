import React from "react";
import { ContactShadows } from "@react-three/drei";

/**
 * Armory — the "sense of place": a dark circular floor, a raised platform with
 * an emissive glowing ring (the avatar stands inside it), back wall, and
 * emissive gear niches echoing the reference image.
 */
export default function Armory({ floorY = 0 }) {
  return (
    <group>
      {/* platform + floor sit at the avatar's feet (floorY) */}
      <group position={[0, floorY, 0]}>
      {/* lighting rig: cool key + purple rim + soft fill */}
      <hemisphereLight args={[0x9b7bff, 0x140a22, 0.5]} />
      <spotLight
        position={[3, 6, 4]}
        angle={0.5}
        penumbra={0.5}
        intensity={120}
        distance={20}
        color={0xcdbbff}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-bias={-0.0004}
      />
      <spotLight
        position={[-4, 4, -3]}
        angle={0.7}
        penumbra={0.6}
        intensity={60}
        distance={22}
        color={0x7b2cff}
      />
      <pointLight position={[0, 2.4, 3]} intensity={12} distance={14} color={0x6a4cff} />

      {/* floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <circleGeometry args={[7, 64]} />
        <meshStandardMaterial color={0x130e1d} roughness={0.65} metalness={0.3} />
      </mesh>

      {/* raised platform */}
      <mesh position={[0, 0.04, 0]} receiveShadow>
        <cylinderGeometry args={[1.0, 1.12, 0.08, 64]} />
        <meshStandardMaterial
          color={0x241834}
          emissive={0x7b2cff}
          emissiveIntensity={0.3}
          roughness={0.45}
          metalness={0.6}
        />
      </mesh>

      {/* glowing ring */}
      <mesh position={[0, 0.09, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <torusGeometry args={[1.02, 0.022, 20, 96]} />
        <meshStandardMaterial
          color={0xc6a8ff}
          emissive={0x9b6bff}
          emissiveIntensity={1.6}
          toneMapped={false}
        />
      </mesh>

      {/* back wall */}
      <mesh position={[0, 3, -5.2]} receiveShadow>
        <planeGeometry args={[14, 6]} />
        <meshStandardMaterial color={0x0e0918} roughness={0.85} metalness={0.2} />
      </mesh>

      {/* gear niches */}
      {[-2, -1, 0, 1, 2].map((i) =>
        [-4.6, 4.6].map((x) => (
          <mesh key={`${i}-${x}`} position={[x, 1.5, i * 1.4 - 1]}>
            <boxGeometry args={[0.12, 1.7, 0.62]} />
            <meshStandardMaterial
              color={0x1a1230}
              emissive={0x7b2cff}
              emissiveIntensity={0.45}
            />
          </mesh>
        ))
      )}

      <ContactShadows position={[0, 0.09, 0]} opacity={0.4} scale={6} blur={2.6} far={4} />
      </group>
    </group>
  );
}
