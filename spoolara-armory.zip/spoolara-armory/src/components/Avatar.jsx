import React, { useEffect, useMemo, useRef } from "react";
import { useGLTF } from "@react-three/drei";
import * as THREE from "three";

const AVATAR_URL = "/models/humanoid.glb";

/**
 * skinnedBounds — TRUE rendered bounds of a (possibly skinned) avatar group.
 *
 * For a SkinnedMesh, geometry.boundingBox / Box3.setFromObject return the REST
 * pose, which need not match what the GPU draws. applyBoneTransform deforms
 * each vertex exactly as the GPU does; we then take it to world space via the
 * mesh's live matrixWorld. Vertices are sampled for speed (~4k points).
 *
 * Returns a world-space Box3, or null if no skinned mesh was found.
 */
function skinnedBounds(group) {
  const box = new THREE.Box3();
  const v = new THREE.Vector3();
  let found = false;
  group.updateMatrixWorld(true);
  group.traverse((o) => {
    if (o.isSkinnedMesh && typeof o.applyBoneTransform === "function") {
      found = true;
      o.updateMatrixWorld(true);
      const pos = o.geometry.attributes.position;
      const step = Math.max(1, Math.floor(pos.count / 4000));
      for (let i = 0; i < pos.count; i += step) {
        v.fromBufferAttribute(pos, i);
        o.applyBoneTransform(i, v);
        v.applyMatrix4(o.matrixWorld);
        box.expandByPoint(v);
      }
    }
  });
  return found ? box : null;
}

/**
 * Avatar — loads the rigged humanoid, scales it so its true rendered height
 * matches the user's height, stands it on the platform, and reports its true
 * (GPU-skinned) bounding box + bone world positions upward. Parts anchor to the
 * box via anatomical ratios; bones drive limb orientation.
 *
 * Transform is applied declaratively so React Three Fiber doesn't overwrite it.
 */
export default function Avatar({ heightCm, onBones }) {
  const { scene } = useGLTF(AVATAR_URL);
  const groupRef = useRef();

  const model = useMemo(() => {
    const clone = scene.clone(true);
    clone.traverse((o) => {
      if (o.isMesh) {
        o.castShadow = true;
        o.receiveShadow = true;
        o.material = new THREE.MeshStandardMaterial({
          color: 0x8a7fb5,
          roughness: 0.55,
          metalness: 0.1,
        });
      }
    });
    return clone;
  }, [scene]);

  // natural rendered height (skinned) at scale 1, measured once on mount
  const baseHeight = useMemo(() => {
    // model isn't in a positioned group yet; measure rest skinned bounds
    const box = skinnedBounds(model) || new THREE.Box3().setFromObject(model);
    const s = new THREE.Vector3();
    box.getSize(s);
    return s.y || 1;
  }, [model]);

  const scale = (heightCm * 0.01) / baseHeight;

  // The skinned mesh renders in its skeleton-defined space, which is NOT moved
  // by the group's position offset (applyBoneTransform is offset-independent).
  // So we DON'T offset the group — we anchor parts in the same skinned space
  // the mesh actually occupies, and place the platform/camera around it.
  useEffect(() => {
    const group = groupRef.current;
    if (!group) return;

    group.position.set(0, 0, 0);
    group.scale.setScalar(scale);
    group.updateMatrixWorld(true);

    const bones = {};
    group.traverse((o) => {
      if (o.name && o.isBone) {
        const wp = new THREE.Vector3();
        o.getWorldPosition(wp);
        bones[o.name] = wp;
      }
    });

    // TRUE rendered box (skinned space) — this is what parts anchor to
    const box = skinnedBounds(group) || new THREE.Box3().setFromObject(group);
    onBones(bones, box);

  }, [scale, onBones]);

  return (
    <group ref={groupRef} scale={scale} position={[0, 0, 0]}>
      <primitive object={model} />
    </group>
  );
}

useGLTF.preload(AVATAR_URL);
