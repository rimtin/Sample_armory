import React from "react";
import { Html, TransformControls } from "@react-three/drei";
import * as THREE from "three";

/** A single fitted armor part. Click to select. */
export function PartMesh({ part, selected, meshRef, onSelect }) {
  const mat = STYLE_MATERIALS[part.style] || STYLE_MATERIALS.Metallic;
  return (
    <mesh
      ref={meshRef}
      geometry={part.geometry}
      position={part.position}
      quaternion={part.quaternion}
      scale={[part.totalScale, part.totalScale, part.totalScale]}
      castShadow
      receiveShadow
      onPointerDown={(e) => {
        e.stopPropagation();
        onSelect(part.id);
      }}
    >
      <meshStandardMaterial
        color={part.color}
        emissive={mat.emissive}
        emissiveIntensity={mat.emissiveIntensity}
        metalness={mat.metalness}
        roughness={mat.roughness}
        side={THREE.DoubleSide}
      />
      {selected && (
        <Html position={[0, 0, 0]} center distanceFactor={6} style={{ pointerEvents: "none" }}>
          <div className="part-tag">{part.filename}</div>
        </Html>
      )}
    </mesh>
  );
}

export const STYLE_MATERIALS = {
  Metallic: { roughness: 0.35, metalness: 0.9, emissive: 0x000000, emissiveIntensity: 0 },
  Matte: { roughness: 0.92, metalness: 0.0, emissive: 0x000000, emissiveIntensity: 0 },
  Glossy: { roughness: 0.1, metalness: 0.4, emissive: 0x000000, emissiveIntensity: 0 },
  Emissive: { roughness: 0.5, metalness: 0.2, emissive: 0x7b2cff, emissiveIntensity: 0.7 },
};

/** Red marker + axes + label where the user clicked the avatar. */
export function PickMarker({ point }) {
  if (!point) return null;
  return (
    <group position={[point.x, point.y, point.z]}>
      <mesh>
        <sphereGeometry args={[0.03, 20, 20]} />
        <meshStandardMaterial color="#ff4d4d" emissive="#ff0000" emissiveIntensity={0.5} toneMapped={false} />
      </mesh>
      <axesHelper args={[0.25]} />
      <Html position={[0.05, 0.05, 0]} distanceFactor={7} style={{ pointerEvents: "none" }}>
        <div className="coord-label">
          X {point.x.toFixed(2)} · Y {point.y.toFixed(2)} · Z {point.z.toFixed(2)}
        </div>
      </Html>
    </group>
  );
}

/** Wrapper so the gizmo only mounts when there's a live mesh to attach to. */
export function Gizmo({ object, mode, orbitRef, onCommit }) {
  if (!object) return null;
  return (
    <TransformControls
      object={object}
      mode={mode}
      onMouseDown={() => orbitRef.current && (orbitRef.current.enabled = false)}
      onMouseUp={() => {
        if (orbitRef.current) orbitRef.current.enabled = true;
        onCommit();
      }}
      onObjectChange={onCommit}
    />
  );
}
