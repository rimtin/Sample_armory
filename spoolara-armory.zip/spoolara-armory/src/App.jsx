import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import { STLLoader } from "three/examples/jsm/loaders/STLLoader.js";
import * as THREE from "three";

import Armory from "./components/Armory.jsx";
import Avatar from "./components/Avatar.jsx";
import { PartMesh, PickMarker, Gizmo } from "./components/SceneParts.jsx";
import MeasurementsPanel from "./components/MeasurementsPanel.jsx";
import PartEditor from "./components/PartEditor.jsx";

import { DEFAULT_MEASUREMENTS, detectRegion } from "./utils/bodyModel.js";
import { computeFit, dimensionsCm } from "./utils/fitting.js";
import { exportPart, exportAssembly } from "./utils/exportStl.js";

let SEQ = 1;
const blankManual = () => ({ scaleMul: 1, offset: { x: 0, y: 0, z: 0 }, rotation: { x: 0, y: 0, z: 0 } });

export default function App() {
  const [measurements, setMeasurements] = useState(DEFAULT_MEASUREMENTS);
  const [parts, setParts] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [gizmoMode, setGizmoMode] = useState("translate");
  const [pick, setPick] = useState(null);
  const [dragging, setDragging] = useState(false);
  const [status, setStatus] = useState("Drop an STL on the scene, or use Import.");
  const [frame, setFrame] = useState({ floorY: 0, centerY: 0.9, height: 1.8 });

  const bonesRef = useRef({}); // live bone world positions
  const avatarBoxRef = useRef(null); // live avatar bounding box
  const orbitRef = useRef();
  const fileInputRef = useRef();
  const meshRefs = useRef({});

  const selected = parts.find((p) => p.id === selectedId) || null;

  const getMeshRef = (id) => {
    if (!meshRefs.current[id]) meshRefs.current[id] = React.createRef();
    return meshRefs.current[id];
  };

  // ---- compose a part's transform from auto-fit + manual ----
  const composePart = useCallback((p, meas) => {
    const fit = computeFit({
      geometry: p.geometry,
      regionId: p.regionId,
      fitLevel: p.fitLevel,
      measurements: meas,
      boneWorld: bonesRef.current,
      avatarBox: avatarBoxRef.current,
    });

    const totalScale = fit.scale * (p.manual.scaleMul ?? 1);

    // base orientation from fit, plus manual euler offset
    const q = new THREE.Quaternion(...fit.quaternion);
    const manQ = new THREE.Quaternion().setFromEuler(
      new THREE.Euler(
        THREE.MathUtils.degToRad(p.manual.rotation?.x ?? 0),
        THREE.MathUtils.degToRad(p.manual.rotation?.y ?? 0),
        THREE.MathUtils.degToRad(p.manual.rotation?.z ?? 0)
      )
    );
    q.multiply(manQ);

    const position = [
      fit.position[0] + (p.manual.offset?.x ?? 0),
      fit.position[1] + (p.manual.offset?.y ?? 0),
      fit.position[2] + (p.manual.offset?.z ?? 0),
    ];

    const dims = dimensionsCm(p.geometry, totalScale);
    return { ...p, totalScale, quaternion: [q.x, q.y, q.z, q.w], position, dims };
  }, []);

  const recomposeAll = useCallback((meas) => {
    setParts((prev) => prev.map((p) => composePart(p, meas)));
  }, [composePart]);

  // bones + bounding box arrive (or change) → refit everything
  const handleBones = useCallback((bones, box) => {
    bonesRef.current = bones;
    if (box) {
      avatarBoxRef.current = box;
      setFrame({
        floorY: box.min.y,
        centerY: (box.min.y + box.max.y) / 2,
        height: box.max.y - box.min.y,
      });
    }
    setParts((prev) => prev.map((p) => composePart(p, measurements)));
  }, [composePart, measurements]);

  const handleMeasure = (key, value) => {
    const next = { ...measurements, [key]: value };
    setMeasurements(next);
    // Avatar effect will fire for height; for others, refit immediately
    recomposeAll(next);
  };

  // ---- import ----
  const importFiles = useCallback((files) => {
    const stls = [...files].filter((f) => f.name.toLowerCase().endsWith(".stl"));
    if (!stls.length) return;
    let pending = stls.length;
    const added = [];
    stls.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const geometry = new STLLoader().parse(e.target.result);
          geometry.computeVertexNormals();
          geometry.center();
          const regionId = detectRegion(file.webkitRelativePath || file.name);
          let part = {
            id: SEQ++,
            filename: file.name,
            regionId,
            fitLevel: "Snug",
            color: "#7b2cff",
            style: "Metallic",
            manual: blankManual(),
            geometry,
          };
          part = composePart(part, measurements);
          added.push(part);
        } catch (err) {
          console.error("STL parse failed", file.name, err);
        } finally {
          if (--pending === 0) {
            setParts((prev) => [...prev, ...added]);
            if (added.length) setSelectedId(added[added.length - 1].id);
            setStatus(`Imported ${added.length} part(s).`);
          }
        }
      };
      reader.readAsArrayBuffer(file);
    });
  }, [composePart, measurements]);

  // ---- edits on selected ----
  const patchSelected = (patch) =>
    setParts((prev) => prev.map((p) => (p.id === selectedId ? composePart({ ...p, ...patch }, measurements) : p)));

  const changeSelected = (patch) => {
    // colour/style don't need refit, but composePart is cheap & keeps dims fresh
    patchSelected(patch);
  };

  const manualSelected = (patch) =>
    setParts((prev) =>
      prev.map((p) => (p.id === selectedId ? composePart({ ...p, manual: { ...p.manual, ...patch } }, measurements) : p))
    );

  const autoFitSelected = (fitLevel) =>
    setParts((prev) =>
      prev.map((p) => (p.id === selectedId ? composePart({ ...p, fitLevel, manual: blankManual() }, measurements) : p))
    );

  const flipSelected = (axis) => {
    if (!selected) return;
    const deg = axis === "z" ? 90 : 180;
    const cur = selected.manual.rotation?.[axis] ?? 0;
    manualSelected({ rotation: { ...selected.manual.rotation, [axis]: cur + deg } });
  };

  const removeSelected = () => {
    setParts((prev) => prev.filter((p) => p.id !== selectedId));
    delete meshRefs.current[selectedId];
    setSelectedId(null);
  };

  // commit a gizmo drag back into manual offsets/rotation/scale
  const commitGizmo = () => {
    const ref = meshRefs.current[selectedId];
    const mesh = ref && ref.current;
    if (!mesh || !selected) return;
    setParts((prev) =>
      prev.map((p) => {
        if (p.id !== selectedId) return p;
        const fit = computeFit({
          geometry: p.geometry,
          regionId: p.regionId,
          fitLevel: p.fitLevel,
          measurements,
          boneWorld: bonesRef.current,
          avatarBox: avatarBoxRef.current,
        });
        const offset = {
          x: mesh.position.x - fit.position[0],
          y: mesh.position.y - fit.position[1],
          z: mesh.position.z - fit.position[2],
        };
        const scaleMul = fit.scale > 1e-9 ? mesh.scale.x / fit.scale : 1;
        const dims = dimensionsCm(p.geometry, mesh.scale.x);
        return {
          ...p,
          manual: { ...p.manual, offset, scaleMul },
          position: [mesh.position.x, mesh.position.y, mesh.position.z],
          quaternion: [mesh.quaternion.x, mesh.quaternion.y, mesh.quaternion.z, mesh.quaternion.w],
          totalScale: mesh.scale.x,
          dims,
        };
      })
    );
  };

  // keyboard shortcuts for gizmo
  useEffect(() => {
    const onKey = (e) => {
      const k = e.key.toLowerCase();
      if (k === "g") setGizmoMode("translate");
      if (k === "r") setGizmoMode("rotate");
      if (k === "s") setGizmoMode("scale");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const selectedMesh = selectedId != null ? meshRefs.current[selectedId]?.current : null;

  return (
    <div
      className="app"
      onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => { e.preventDefault(); setDragging(false); importFiles(e.dataTransfer.files); }}
    >
      <div className="bg-overlay" />
      {dragging && <div className="drop-veil"><div className="drop-card">Drop STL to fit it to your avatar</div></div>}

      <Canvas
        shadows
        className="three-canvas"
        camera={{ position: [0, 1.1, 4.6], fov: 42 }}
        gl={{ alpha: true, antialias: true }}
        onCreated={({ gl }) => {
          gl.toneMapping = THREE.ACESFilmicToneMapping;
          gl.toneMappingExposure = 1.1;
          gl.outputColorSpace = THREE.SRGBColorSpace;
        }}
        onPointerMissed={() => setSelectedId(null)}
      >
        <Armory floorY={frame.floorY} />

        <group onPointerDown={(e) => { e.stopPropagation(); const p = e.point; setPick({ x: p.x, y: p.y, z: p.z }); }}>
          <Avatar heightCm={measurements.height} onBones={handleBones} />
        </group>

        <PickMarker point={pick} />

        {parts.map((p) => (
          <PartMesh
            key={p.id}
            part={p}
            selected={p.id === selectedId}
            meshRef={getMeshRef(p.id)}
            onSelect={setSelectedId}
          />
        ))}

        <Gizmo object={selectedMesh} mode={gizmoMode} orbitRef={orbitRef} onCommit={commitGizmo} />

        <OrbitControls ref={orbitRef} target={[0, frame.centerY, 0]} enablePan enableZoom enableRotate
          minDistance={0.6} maxDistance={9} maxPolarAngle={Math.PI * 0.52} />
      </Canvas>

      {/* LEFT */}
      <aside className="sidebar sidebar-left">
        <header className="brand"><span className="brand-mark">◆</span><span><strong>Spoolara</strong> Armory</span></header>
        <MeasurementsPanel values={measurements} onChange={handleMeasure} />
      </aside>

      {/* RIGHT */}
      <aside className="sidebar sidebar-right">
        <section className="card">
          <h3 className="card-title">Gear</h3>
          <p className="card-sub">{status}</p>
          <div className="btn-stack">
            <button className="btn btn-accent block" onClick={() => fileInputRef.current.click()}>Import STL</button>
            {parts.length > 0 && (
              <button className="btn btn-ghost block" onClick={() => exportAssembly(parts)}>
                Export assembly ({parts.length}, mm)
              </button>
            )}
          </div>
          <input ref={fileInputRef} type="file" accept=".stl" multiple className="hidden"
            onChange={(e) => { importFiles(e.target.files); e.target.value = ""; }} />

          {parts.length > 0 && (
            <div className="part-list">
              {parts.map((p) => (
                <button key={p.id}
                  className={"part-chip" + (p.id === selectedId ? " active" : "")}
                  onClick={() => setSelectedId(p.id)} title={p.filename}>
                  <span className="chip-name">{p.filename}</span>
                  <span className="chip-region">{p.regionId}</span>
                </button>
              ))}
            </div>
          )}
        </section>

        {selected ? (
          <PartEditor
            part={selected}
            gizmoMode={gizmoMode}
            onGizmo={setGizmoMode}
            onChange={changeSelected}
            onManual={manualSelected}
            onAutoFit={autoFitSelected}
            onFlip={flipSelected}
            onExport={() => exportPart(selected)}
            onRemove={removeSelected}
          />
        ) : (
          <div className="empty">No part selected. Import or drop an STL, then click it to edit the fit.</div>
        )}

        {pick && (
          <section className="card compact">
            <h3 className="card-title">Coordinate pick</h3>
            <p className="card-sub">X {pick.x.toFixed(2)} · Y {pick.y.toFixed(2)} · Z {pick.z.toFixed(2)}</p>
            <div className="btn-stack">
              <button className="btn btn-ghost block" disabled={!selected}
                onClick={() => selected && manualSelected({
                  offset: {
                    x: pick.x - (selected.position[0] - (selected.manual.offset?.x ?? 0)),
                    y: pick.y - (selected.position[1] - (selected.manual.offset?.y ?? 0)),
                    z: pick.z - (selected.position[2] - (selected.manual.offset?.z ?? 0)),
                  },
                })}>
                Move selected here
              </button>
              <button className="btn btn-ghost block" onClick={() => setPick(null)}>Clear pick</button>
            </div>
          </section>
        )}
      </aside>
    </div>
  );
}
